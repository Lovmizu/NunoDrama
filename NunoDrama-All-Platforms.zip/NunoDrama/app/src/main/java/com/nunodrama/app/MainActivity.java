package com.nunodrama.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final String HOME = "https://nunodrama.my.id/";
    private WebView webView;
    private LinearLayout root, toolbar;
    private ProgressBar progress;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private int oldOrientation;
    private SharedPreferences prefs;
    private final List<String> history = new ArrayList<>();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16,16,16));
        getWindow().setNavigationBarColor(Color.BLACK);
        prefs = getSharedPreferences("nunodrama", MODE_PRIVATE);
        loadHistory();
        buildLayout();
        configureWebView();
        if (savedInstanceState == null) webView.loadUrl(HOME);
        else webView.restoreState(savedInstanceState);
    }

    private void buildLayout() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.BLACK);
        FrameLayout webFrame = new FrameLayout(this);
        webView = new WebView(this);
        webFrame.addView(webView, new FrameLayout.LayoutParams(-1,-1));
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100); progress.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(229,57,53)));
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, dp(3), Gravity.TOP);
        webFrame.addView(progress, pp);
        root.addView(webFrame, new LinearLayout.LayoutParams(-1,0,1));

        toolbar = new LinearLayout(this); toolbar.setGravity(Gravity.CENTER); toolbar.setBackgroundColor(Color.rgb(16,16,16));
        addNavButton("‹  Kembali", () -> goBack());
        addNavButton("⌂  Beranda", () -> webView.loadUrl(HOME));
        addNavButton("▤  Riwayat", () -> showHistory());
        root.addView(toolbar, new LinearLayout.LayoutParams(-1,dp(54)));
        setContentView(root);
    }

    private void addNavButton(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(12);
        b.setAllCaps(false); b.setBackgroundColor(Color.TRANSPARENT); b.setOnClickListener(v -> action.run());
        toolbar.addView(b, new LinearLayout.LayoutParams(0,-1,1));
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false); s.setLoadsImagesAutomatically(true);
        s.setSupportZoom(false); s.setBuiltInZoomControls(false); s.setAllowFileAccess(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.setBackgroundColor(Color.BLACK);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme));
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) { saveVisit(url); }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) { progress.setProgress(value); progress.setVisibility(value >= 100 ? View.GONE : View.VISIBLE); }
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) { callback.onCustomViewHidden(); return; }
                customView = view; customViewCallback = callback; oldOrientation = getRequestedOrientation();
                toolbar.setVisibility(View.GONE); webView.setVisibility(View.GONE); progress.setVisibility(View.GONE);
                ((ViewGroup) root).addView(customView, new LinearLayout.LayoutParams(-1,-1));
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            }
            @Override public void onHideCustomView() { hideCustomView(); }
        });
    }

    private void hideCustomView() {
        if (customView == null) return;
        ((ViewGroup) root).removeView(customView); customView = null;
        toolbar.setVisibility(View.VISIBLE); webView.setVisibility(View.VISIBLE);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        if (customViewCallback != null) { customViewCallback.onCustomViewHidden(); customViewCallback = null; }
    }

    private void saveVisit(String url) {
        if (url == null || !url.startsWith("http")) return;
        history.remove(url); history.add(0,url);
        while (history.size() > 100) history.remove(history.size()-1);
        JSONArray a = new JSONArray(); for (String item : history) a.put(item);
        prefs.edit().putString("history", a.toString()).apply();
    }
    private void loadHistory() {
        String raw = prefs.getString("history", "[]");
        try { JSONArray a = new JSONArray(raw); for (int i=0;i<a.length();i++) history.add(a.getString(i)); }
        catch (JSONException ignored) { }
    }
    private void showHistory() {
        if (history.isEmpty()) { new AlertDialog.Builder(this).setTitle("Riwayat tontonan").setMessage("Belum ada riwayat.").setPositiveButton("Tutup",null).show(); return; }
        String[] items = new String[history.size()];
        for (int i=0;i<history.size();i++) { String u=history.get(i); items[i]=u.length()>58 ? u.substring(0,55)+"…" : u; }
        new AlertDialog.Builder(this).setTitle("Riwayat tontonan").setItems(items,(d,which)->webView.loadUrl(history.get(which)))
            .setNeutralButton("Hapus riwayat",(d,w)->{ history.clear(); prefs.edit().remove("history").apply(); Toast.makeText(this,"Riwayat dihapus",Toast.LENGTH_SHORT).show(); })
            .setNegativeButton("Tutup",null).show();
    }
    private void goBack() { if (customView != null) { hideCustomView(); return; } if (webView.canGoBack()) webView.goBack(); else webView.loadUrl(HOME); }
    @Override public void onBackPressed() { if (customView != null) hideCustomView(); else if (webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); if (webView != null) webView.saveState(out); }
    @Override protected void onDestroy() { if (webView != null) { webView.destroy(); } super.onDestroy(); }
    private int dp(int v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
}
