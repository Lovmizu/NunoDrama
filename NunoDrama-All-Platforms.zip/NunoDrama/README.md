# NunoDrama Android WebView

Aplikasi Android WebView untuk membuka https://nunodrama.my.id/.

## Fitur
- Halaman awal langsung ke platform semua platform NunoDrama.
- WebView dengan JavaScript, DOM Storage, cookie dan pemutaran media.
- Fullscreen video melalui WebChromeClient.
- Riwayat URL yang dikunjungi tersimpan lokal (maksimal 100 entri).
- Tombol Kembali, Beranda, dan Riwayat.

## Build lewat GitHub Actions
1. Buat repository GitHub baru bernama `NunoDrama`.
2. Upload seluruh isi folder proyek ini ke root repository (bukan folder pembungkus `NunoDrama`). Pastikan folder `.github/workflows` ikut terunggah.
3. Buka tab Actions dan pilih `Build NunoDrama APK`.
4. Tekan `Run workflow`.
5. Setelah build berhasil, unduh artifact `NunoDrama-debug-apk`.
6. Ekstrak artifact dan instal `app-debug.apk` di Android.

## Catatan
Aplikasi ini hanya membungkus situs dalam WebView. Riwayat menyimpan URL halaman yang dikunjungi, bukan metadata judul/episode yang mungkin dimuat dinamis. Ketersediaan video, login, dan fullscreen tetap bergantung pada situs dan penyedia konten. Gunakan hanya konten yang Anda berhak akses.
